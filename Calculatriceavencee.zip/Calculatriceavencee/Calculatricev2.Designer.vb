﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        B0 = New Button()
        B6 = New Button()
        B5 = New Button()
        B4 = New Button()
        B3 = New Button()
        B2 = New Button()
        B1 = New Button()
        B_Clear = New Button()
        B_Div = New Button()
        B_Minus = New Button()
        B_plus = New Button()
        B_equal = New Button()
        B9 = New Button()
        B8 = New Button()
        B7 = New Button()
        B_Multi = New Button()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(163, 93)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(402, 27)
        TextBox1.TabIndex = 0
        ' 
        ' B0
        ' 
        B0.BackColor = Color.CornflowerBlue
        B0.Location = New Point(163, 157)
        B0.Name = "B0"
        B0.Size = New Size(96, 29)
        B0.TabIndex = 1
        B0.Text = "0"
        B0.UseVisualStyleBackColor = False
        ' 
        ' B6
        ' 
        B6.BackColor = Color.CornflowerBlue
        B6.Location = New Point(367, 197)
        B6.Name = "B6"
        B6.Size = New Size(96, 29)
        B6.TabIndex = 2
        B6.Text = "6"
        B6.UseVisualStyleBackColor = False
        ' 
        ' B5
        ' 
        B5.BackColor = Color.CornflowerBlue
        B5.Location = New Point(265, 197)
        B5.Name = "B5"
        B5.Size = New Size(96, 29)
        B5.TabIndex = 3
        B5.Text = "5"
        B5.UseVisualStyleBackColor = False
        ' 
        ' B4
        ' 
        B4.BackColor = Color.CornflowerBlue
        B4.Location = New Point(163, 197)
        B4.Name = "B4"
        B4.Size = New Size(96, 29)
        B4.TabIndex = 4
        B4.Text = "4"
        B4.UseVisualStyleBackColor = False
        ' 
        ' B3
        ' 
        B3.BackColor = Color.CornflowerBlue
        B3.Location = New Point(469, 157)
        B3.Name = "B3"
        B3.Size = New Size(96, 29)
        B3.TabIndex = 5
        B3.Text = "3"
        B3.UseVisualStyleBackColor = False
        ' 
        ' B2
        ' 
        B2.BackColor = Color.CornflowerBlue
        B2.Location = New Point(367, 157)
        B2.Name = "B2"
        B2.Size = New Size(96, 29)
        B2.TabIndex = 6
        B2.Text = "2"
        B2.UseVisualStyleBackColor = False
        ' 
        ' B1
        ' 
        B1.BackColor = Color.CornflowerBlue
        B1.Location = New Point(265, 157)
        B1.Name = "B1"
        B1.Size = New Size(96, 29)
        B1.TabIndex = 7
        B1.Text = "1"
        B1.UseVisualStyleBackColor = False
        ' 
        ' B_Clear
        ' 
        B_Clear.BackColor = Color.CornflowerBlue
        B_Clear.Location = New Point(367, 239)
        B_Clear.Name = "B_Clear"
        B_Clear.Size = New Size(96, 29)
        B_Clear.TabIndex = 8
        B_Clear.Text = "C"
        B_Clear.UseVisualStyleBackColor = False
        ' 
        ' B_Div
        ' 
        B_Div.BackColor = Color.CornflowerBlue
        B_Div.Location = New Point(470, 274)
        B_Div.Name = "B_Div"
        B_Div.Size = New Size(96, 29)
        B_Div.TabIndex = 9
        B_Div.Text = "/"
        B_Div.UseVisualStyleBackColor = False
        ' 
        ' B_Minus
        ' 
        B_Minus.BackColor = Color.CornflowerBlue
        B_Minus.Location = New Point(265, 274)
        B_Minus.Name = "B_Minus"
        B_Minus.Size = New Size(96, 29)
        B_Minus.TabIndex = 10
        B_Minus.Text = "-"
        B_Minus.UseVisualStyleBackColor = False
        ' 
        ' B_plus
        ' 
        B_plus.BackColor = Color.CornflowerBlue
        B_plus.Location = New Point(163, 274)
        B_plus.Name = "B_plus"
        B_plus.Size = New Size(96, 29)
        B_plus.TabIndex = 11
        B_plus.Text = "+"
        B_plus.UseVisualStyleBackColor = False
        ' 
        ' B_equal
        ' 
        B_equal.BackColor = Color.CornflowerBlue
        B_equal.Location = New Point(469, 239)
        B_equal.Name = "B_equal"
        B_equal.Size = New Size(96, 29)
        B_equal.TabIndex = 12
        B_equal.Text = "="
        B_equal.UseVisualStyleBackColor = False
        ' 
        ' B9
        ' 
        B9.BackColor = Color.CornflowerBlue
        B9.Location = New Point(265, 239)
        B9.Name = "B9"
        B9.Size = New Size(96, 29)
        B9.TabIndex = 13
        B9.Text = "9"
        B9.UseVisualStyleBackColor = False
        ' 
        ' B8
        ' 
        B8.BackColor = Color.CornflowerBlue
        B8.Location = New Point(163, 239)
        B8.Name = "B8"
        B8.Size = New Size(96, 29)
        B8.TabIndex = 14
        B8.Text = "8"
        B8.UseVisualStyleBackColor = False
        ' 
        ' B7
        ' 
        B7.BackColor = Color.CornflowerBlue
        B7.Location = New Point(469, 197)
        B7.Name = "B7"
        B7.Size = New Size(96, 29)
        B7.TabIndex = 15
        B7.Text = "7"
        B7.UseVisualStyleBackColor = False
        ' 
        ' B_Multi
        ' 
        B_Multi.BackColor = Color.CornflowerBlue
        B_Multi.Location = New Point(367, 274)
        B_Multi.Name = "B_Multi"
        B_Multi.Size = New Size(96, 29)
        B_Multi.TabIndex = 16
        B_Multi.Text = "*"
        B_Multi.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(B_Multi)
        Controls.Add(B7)
        Controls.Add(B8)
        Controls.Add(B9)
        Controls.Add(B_equal)
        Controls.Add(B_plus)
        Controls.Add(B_Minus)
        Controls.Add(B_Div)
        Controls.Add(B_Clear)
        Controls.Add(B1)
        Controls.Add(B2)
        Controls.Add(B3)
        Controls.Add(B4)
        Controls.Add(B5)
        Controls.Add(B6)
        Controls.Add(B0)
        Controls.Add(TextBox1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents B0 As Button
    Friend WithEvents B6 As Button
    Friend WithEvents B5 As Button
    Friend WithEvents B4 As Button
    Friend WithEvents B3 As Button
    Friend WithEvents B2 As Button
    Friend WithEvents B1 As Button
    Friend WithEvents B_Clear As Button
    Friend WithEvents B_Div As Button
    Friend WithEvents B_Minus As Button
    Friend WithEvents B_plus As Button
    Friend WithEvents B_equal As Button
    Friend WithEvents B9 As Button
    Friend WithEvents B8 As Button
    Friend WithEvents B7 As Button
    Friend WithEvents B_Multi As Button

End Class
